# PackRat

Android app that turns a private Telegram channel into your personal cloud
storage — your own account, no PackRat server, no account to create with
anyone else. Modeled on the architecture and feature set of
[TeleDrive](https://github.com/Mahmud0808/TeleDrive), rebuilt from scratch
under the PackRat name.

Stack: Kotlin, Jetpack Compose, Material 3, Hilt, Room, WorkManager, Paging 3,
Media3, Coil, TDLib (via the prebuilt `tdlibx/td` AAR — no NDK build needed).

## What's actually implemented vs. scaffolded

This was generated in one pass without a compiler available, so be honest
with yourself about what you're getting:

**Solid, real logic:**
- Full Gradle project structure (modules, dependencies, manifest, per-ABI APK splits)
- `CryptoManager` — real AES-256-GCM streaming encryption, Keystore key
  wrapping, and PBKDF2 (310k iterations) passphrase-sealed key backup
- `TelegramClient` interface + a `TdLibTelegramClient` implementation using
  real TDLib call patterns (auth flow, send/download file, edit caption,
  delete message)
- Room schema (drives, drive items, transfers, backup rules) with DAOs and
  paging support
- WorkManager-based transfer queue skeleton (`TransferManager`, `TransferWorker`)
- Compose screens for auth, home, file browsing, and settings, wired to
  Hilt ViewModels

**Stubbed with clear TODO comments** (the pieces that need real device/TDLib
testing to get right, so I left them as marked scaffolding rather than
guessing):
- `TransferWorker.doWork()` — the actual upload/download execution loop
- `BackupSweepWorker` — the diff-and-enqueue logic for automatic backup
- QR login link handling, "Confirm in Telegram" deep link
- Gallery/media viewer, PDF/ZIP preview, biometric app lock enforcement
- Trash, favorites, and archive UI actions (DAOs support them; screens don't
  expose them yet)

Treat this as a real architectural foundation, not a finished app — the
remaining pieces are exactly the kind of thing worth doing incrementally,
each one testable on its own.

## Building without a PC (GitHub Actions)

Since you're on-device with no local build setup, this repo includes
`.github/workflows/build.yml`, which builds a debug APK on GitHub's servers
every time you push:

1. Create a new GitHub repo (or reuse an existing one) and push this project to it.
2. Go to the repo's **Actions** tab in your phone's browser.
3. Open the latest **Build PackRat APK** run once it finishes (a few minutes).
4. Scroll to **Artifacts** and download `packrat-debug-apks` — it's a zip
   containing the per-ABI APKs. Unzip and install the one matching your
   device (arm64-v8a covers almost every phone from the last several years).
5. You'll need to allow "install unknown apps" for your browser/file manager
   the first time.

If a build fails, open the failed run and check the log — most first-build
failures are dependency-version mismatches, which are easy to spot from the
error message even without deep Android experience.

## Telegram API credentials

Get your own `api_id` / `api_hash` for free at
[my.telegram.org](https://my.telegram.org) → **API development tools**. The
app asks for these on first launch; they're stored encrypted on-device and
never bundled into the app or sent anywhere but Telegram.

## Architecture

```
app/src/main/java/com/packrat/app/
├── core/
│   ├── common/       # AppResult / AppError
│   ├── crypto/       # CryptoManager (Keystore, AES-GCM, PBKDF2)
│   ├── telegram/      # TelegramClient abstraction + TDLib implementation
│   └── transfer/      # Transfer queue: manager, worker, foreground service
├── data/local/        # Room entities, DAOs, database
├── di/                 # Hilt modules
├── domain/model/       # Plain Kotlin models
└── presentation/        # Compose screens + ViewModels (auth, home, files, settings)
```

## License

Apache-2.0, matching the project this was modeled on.
