package com.packrat.app.presentation.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.packrat.app.core.telegram.TelegramClient
import com.packrat.app.domain.model.AuthState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AuthViewModel @Inject constructor(
    private val telegramClient: TelegramClient,
) : ViewModel() {

    val authState: StateFlow<AuthState> = telegramClient.authState.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), AuthState.LoggedOut,
    )

    fun submitApiCredentials(apiId: String, apiHash: String) {
        val id = apiId.toIntOrNull() ?: return
        viewModelScope.launch { telegramClient.setApiCredentials(id, apiHash) }
    }

    fun submitPhoneNumber(phoneNumber: String) {
        viewModelScope.launch { telegramClient.sendPhoneNumber(phoneNumber) }
    }

    fun submitLoginCode(code: String) {
        viewModelScope.launch { telegramClient.sendLoginCode(code) }
    }

    fun submitPassword(password: String) {
        viewModelScope.launch { telegramClient.sendPassword(password) }
    }

    fun startQrLogin() {
        viewModelScope.launch { telegramClient.requestQrLogin().collect { /* surface link to UI as a QR code */ } }
    }
}
