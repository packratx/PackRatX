package com.packrat.app.presentation.settings

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun SettingsScreen(onBack: () -> Unit, viewModel: SettingsViewModel = hiltViewModel()) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
            )
        },
    ) { padding ->
        Column(modifier = Modifier.padding(padding).padding(16.dp)) {
            SettingRow(
                title = "Encrypt uploads",
                subtitle = "AES-256-GCM, requires a recovery passphrase",
                checked = state.encryptionEnabled,
                onCheckedChange = viewModel::onEncryptionToggled,
            )
            SettingRow(
                title = "Wi-Fi only",
                subtitle = "Pause transfers on mobile data",
                checked = state.wifiOnly,
                onCheckedChange = viewModel::onWifiOnlyToggled,
            )
            SettingRow(
                title = "Charging only",
                subtitle = "Only back up while charging",
                checked = state.chargingOnly,
                onCheckedChange = viewModel::onChargingOnlyToggled,
            )
            SettingRow(
                title = "App lock",
                subtitle = "Require biometric unlock to open PackRat",
                checked = state.appLockEnabled,
                onCheckedChange = viewModel::onAppLockToggled,
            )
            SettingRow(
                title = "Block screenshots",
                subtitle = "Prevent screenshots and screen recording",
                checked = state.blockScreenshots,
                onCheckedChange = viewModel::onBlockScreenshotsToggled,
            )
        }
    }
}

@Composable
private fun SettingRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Column(modifier = Modifier.padding(end = 16.dp)) {
            Text(title, style = androidx.compose.material3.MaterialTheme.typography.bodyLarge)
            Text(subtitle, style = androidx.compose.material3.MaterialTheme.typography.bodySmall)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
