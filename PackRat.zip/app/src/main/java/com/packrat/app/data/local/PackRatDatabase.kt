package com.packrat.app.data.local

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [
        DriveEntity::class,
        DriveItemEntity::class,
        TransferEntity::class,
        BackupRuleEntity::class,
    ],
    version = 1,
    exportSchema = true,
)
abstract class PackRatDatabase : RoomDatabase() {
    abstract fun driveDao(): DriveDao
    abstract fun driveItemDao(): DriveItemDao
    abstract fun transferDao(): TransferDao
    abstract fun backupRuleDao(): BackupRuleDao
}
