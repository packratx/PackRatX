package com.packrat.app.core.transfer

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject

/**
 * Runs hourly (scheduled as periodic work from PackRatApplication) and after
 * boot. Diffs each watched folder against the local index by size, modified
 * time and SHA-256, and enqueues uploads for anything new or changed that a
 * missed MediaStore wake-up would otherwise have skipped.
 */
@HiltWorker
class BackupSweepWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val transferManager: TransferManager,
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        // Full implementation: for each enabled BackupRule, list files under
        // watchedFolderPath, compare against DriveItemDao by (size, mtime,
        // sha256), and call transferManager.enqueueUpload for anything not
        // already backed up. Incremental by design: unchanged files are
        // never re-uploaded.
        return Result.success()
    }
}
