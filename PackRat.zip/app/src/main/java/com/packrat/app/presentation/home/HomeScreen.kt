package com.packrat.app.presentation.home

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle

/**
 * Home screen: storage breakdown by category (photos, videos, audio,
 * documents, archives, other — only categories actually present are
 * listed), plus current backup/sync status.
 */
@Composable
fun HomeScreen(
    onOpenFolder: (Long?) -> Unit,
    onOpenSettings: () -> Unit,
    viewModel: HomeViewModel = hiltViewModel(),
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("PackRat") },
                actions = {
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                },
            )
        },
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Text("Storage", style = androidx.compose.material3.MaterialTheme.typography.titleMedium)
            uiState.storageBreakdown.forEach { category ->
                Text("${category.label}: ${category.formattedSize}")
                LinearProgressIndicator(progress = { category.fraction }, modifier = Modifier.fillMaxSize())
            }

            Text("Backup status", style = androidx.compose.material3.MaterialTheme.typography.titleMedium)
            Text(uiState.backupStatusText)
        }
    }
}
