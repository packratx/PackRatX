package com.packrat.app.presentation.settings

import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject

data class SettingsUiState(
    val encryptionEnabled: Boolean = false,
    val wifiOnly: Boolean = true,
    val chargingOnly: Boolean = false,
    val appLockEnabled: Boolean = false,
    val blockScreenshots: Boolean = false,
)

/**
 * Backed by DataStore in the full implementation. Toggling encryption on
 * for the first time triggers the CryptoManager passphrase-setup flow
 * (generate content key -> ask for a recovery passphrase -> seal the key
 * -> upload the key-backup document to the channel) before the switch
 * actually flips.
 */
@HiltViewModel
class SettingsViewModel @Inject constructor() : ViewModel() {

    private val _uiState = MutableStateFlow(SettingsUiState())
    val uiState: StateFlow<SettingsUiState> = _uiState.asStateFlow()

    fun onEncryptionToggled(enabled: Boolean) {
        _uiState.value = _uiState.value.copy(encryptionEnabled = enabled)
    }

    fun onWifiOnlyToggled(enabled: Boolean) {
        _uiState.value = _uiState.value.copy(wifiOnly = enabled)
    }

    fun onChargingOnlyToggled(enabled: Boolean) {
        _uiState.value = _uiState.value.copy(chargingOnly = enabled)
    }

    fun onAppLockToggled(enabled: Boolean) {
        _uiState.value = _uiState.value.copy(appLockEnabled = enabled)
    }

    fun onBlockScreenshotsToggled(enabled: Boolean) {
        _uiState.value = _uiState.value.copy(blockScreenshots = enabled)
    }
}
