package com.packrat.app.presentation.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.packrat.app.presentation.auth.AuthScreen
import com.packrat.app.presentation.files.FilesScreen
import com.packrat.app.presentation.home.HomeScreen
import com.packrat.app.presentation.settings.SettingsScreen

object Routes {
    const val AUTH = "auth"
    const val HOME = "home"
    const val FILES = "files/{folderId}"
    const val SETTINGS = "settings"

    fun files(folderId: Long?) = "files/${folderId ?: -1}"
}

@Composable
fun PackRatNavHost(navController: NavHostController = rememberNavController()) {
    NavHost(navController = navController, startDestination = Routes.AUTH) {
        composable(Routes.AUTH) {
            AuthScreen(onAuthenticated = {
                navController.navigate(Routes.HOME) {
                    popUpTo(Routes.AUTH) { inclusive = true }
                }
            })
        }
        composable(Routes.HOME) {
            HomeScreen(
                onOpenFolder = { folderId -> navController.navigate(Routes.files(folderId)) },
                onOpenSettings = { navController.navigate(Routes.SETTINGS) },
            )
        }
        composable(Routes.FILES) { backStackEntry ->
            val folderId = backStackEntry.arguments?.getString("folderId")?.toLongOrNull()?.takeIf { it != -1L }
            FilesScreen(
                folderId = folderId,
                onOpenFolder = { id -> navController.navigate(Routes.files(id)) },
                onBack = { navController.popBackStack() },
            )
        }
        composable(Routes.SETTINGS) {
            SettingsScreen(onBack = { navController.popBackStack() })
        }
    }
}
