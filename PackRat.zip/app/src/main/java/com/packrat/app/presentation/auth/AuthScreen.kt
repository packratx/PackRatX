package com.packrat.app.presentation.auth

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.packrat.app.domain.model.AuthState

/**
 * Walks through: API id/hash entry -> phone number OR QR code -> login code
 * -> optional 2FA password -> authenticated. Matches TeleDrive's "Confirm in
 * Telegram" shortcut when Telegram is already installed on-device (surfaced
 * once the QR flow's deep link is wired up).
 */
@Composable
fun AuthScreen(onAuthenticated: () -> Unit) {
    val viewModel: AuthViewModel = hiltViewModel()
    val authState by viewModel.authState.collectAsStateWithLifecycle()

    LaunchedEffect(authState) {
        if (authState is AuthState.Authenticated) onAuthenticated()
    }

    Scaffold { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(24.dp),
            verticalArrangement = Arrangement.Center,
        ) {
            Text("Sign in to PackRat", style = androidx.compose.material3.MaterialTheme.typography.headlineSmall)

            when (val state = authState) {
                AuthState.LoggedOut, AuthState.WaitingForApiCredentials -> ApiCredentialsStep(viewModel)
                AuthState.WaitingForPhoneNumber -> PhoneNumberStep(viewModel)
                is AuthState.WaitingForCode -> LoginCodeStep(viewModel)
                AuthState.WaitingForQrConfirmation -> Text("Waiting for confirmation in Telegram…")
                AuthState.WaitingForPassword -> PasswordStep(viewModel)
                AuthState.Authenticating -> CircularProgressIndicator()
                AuthState.Authenticated -> Unit
            }
        }
    }
}

@Composable
private fun ApiCredentialsStep(viewModel: AuthViewModel) {
    var apiId by remember { mutableStateOf("") }
    var apiHash by remember { mutableStateOf("") }
    Text("Enter your Telegram API credentials from my.telegram.org")
    OutlinedTextField(value = apiId, onValueChange = { apiId = it }, label = { Text("API ID") })
    OutlinedTextField(value = apiHash, onValueChange = { apiHash = it }, label = { Text("API Hash") })
    Button(onClick = { viewModel.submitApiCredentials(apiId, apiHash) }) { Text("Continue") }
}

@Composable
private fun PhoneNumberStep(viewModel: AuthViewModel) {
    var phone by remember { mutableStateOf("") }
    OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Phone number") })
    Button(onClick = { viewModel.submitPhoneNumber(phone) }) { Text("Send code") }
    TextButton(onClick = { viewModel.startQrLogin() }) { Text("Sign in by QR code instead") }
}

@Composable
private fun LoginCodeStep(viewModel: AuthViewModel) {
    var code by remember { mutableStateOf("") }
    OutlinedTextField(value = code, onValueChange = { code = it }, label = { Text("Login code") })
    Button(onClick = { viewModel.submitLoginCode(code) }) { Text("Verify") }
}

@Composable
private fun PasswordStep(viewModel: AuthViewModel) {
    var password by remember { mutableStateOf("") }
    OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("2FA password") })
    Button(onClick = { viewModel.submitPassword(password) }) { Text("Unlock") }
}
