package com.packrat.app.presentation.files

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import androidx.paging.cachedIn
import com.packrat.app.data.local.DriveDao
import com.packrat.app.data.local.DriveItemDao
import com.packrat.app.data.local.DriveItemEntity
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import javax.inject.Inject

@HiltViewModel
class FilesViewModel @Inject constructor(
    private val driveDao: DriveDao,
    private val driveItemDao: DriveItemDao,
    savedStateHandle: SavedStateHandle,
) : ViewModel() {

    private val folderId: Long? =
        savedStateHandle.get<String>("folderId")?.toLongOrNull()?.takeIf { it != -1L }

    /** Paged list of items in the current folder — nested folders, files, and their state. */
    val items: Flow<PagingData<DriveItemEntity>> = flow {
        val drive = driveDao.getActive()
        if (drive != null) {
            emitAll(
                Pager(PagingConfig(pageSize = 60)) {
                    driveItemDao.pagingByFolder(drive.id, folderId)
                }.flow,
            )
        }
    }.cachedIn(viewModelScope)

    // Grid vs list layout, sort order (name/size/date/type), and multi-select
    // range selection state live here in the full implementation, backed by
    // DataStore for the layout/sort preference so it persists across launches.
}
