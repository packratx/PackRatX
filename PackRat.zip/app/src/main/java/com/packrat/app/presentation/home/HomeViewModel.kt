package com.packrat.app.presentation.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.packrat.app.core.transfer.TransferManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class StorageCategory(val label: String, val formattedSize: String, val fraction: Float)

data class HomeUiState(
    val storageBreakdown: List<StorageCategory> = emptyList(),
    val backupStatusText: String = "Idle",
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val transferManager: TransferManager,
) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            transferManager.observeActiveTransfers().collect { active ->
                _uiState.value = _uiState.value.copy(
                    backupStatusText = if (active.isEmpty()) "Up to date" else "Syncing ${active.size} item(s)…",
                )
            }
        }
        // Storage breakdown is populated from DriveItemDao.storageBreakdown(driveId)
        // in the full implementation, converted to StorageCategory with
        // human-readable sizes and each category's share of total used space.
    }
}
