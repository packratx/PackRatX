package com.packrat.app.core.telegram

import com.packrat.app.core.common.AppResult
import com.packrat.app.domain.model.AuthState
import kotlinx.coroutines.flow.Flow

/**
 * Abstraction over TDLib so that no `org.drinkless.tdlib.*` type ever leaves
 * this package (mirrors TeleDrive's "no TDLib type leaves core/telegram" rule).
 * Everything above this layer talks in terms of plain Kotlin types.
 */
interface TelegramClient {

    val authState: Flow<AuthState>

    suspend fun setApiCredentials(apiId: Int, apiHash: String)

    suspend fun sendPhoneNumber(phoneNumber: String): AppResult<Unit>

    suspend fun sendLoginCode(code: String): AppResult<Unit>

    suspend fun sendPassword(password: String): AppResult<Unit>

    suspend fun requestQrLogin(): Flow<String> // emits QR login link(s) as they refresh

    suspend fun logOut(): AppResult<Unit>

    /** Finds an existing PackRat storage channel or creates a new one. */
    suspend fun findOrCreateStorageChannel(name: String): AppResult<Long>

    /** Uploads a local file to the given channel, returns the Telegram message id. */
    suspend fun uploadFile(
        channelId: Long,
        localPath: String,
        captionJson: String,
        onProgress: (bytesSent: Long, totalBytes: Long) -> Unit,
    ): AppResult<Long>

    /** Downloads (optionally ranged, for streaming playback) a remote file to a local path. */
    suspend fun downloadFile(
        channelId: Long,
        messageId: Long,
        destinationPath: String,
        rangeStart: Long? = null,
        rangeEnd: Long? = null,
        onProgress: (bytesReceived: Long, totalBytes: Long) -> Unit,
    ): AppResult<String>

    suspend fun deleteMessage(channelId: Long, messageId: Long): AppResult<Unit>

    suspend fun editCaption(channelId: Long, messageId: Long, newCaptionJson: String): AppResult<Unit>

    /** Reads back every manifest caption in the channel, used to rebuild the index after a wipe. */
    suspend fun scanChannelManifests(channelId: Long): Flow<Pair<Long, String>> // messageId to captionJson
}
