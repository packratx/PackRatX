package com.packrat.app.core.crypto

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.io.InputStream
import java.io.OutputStream
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.CipherOutputStream
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec
import javax.inject.Inject
import javax.inject.Singleton
import javax.crypto.SecretKeyFactory

private const val ANDROID_KEYSTORE = "AndroidKeyStore"
private const val MASTER_KEY_ALIAS = "packrat_master_key"
private const val GCM_TAG_BITS = 128
private const val GCM_IV_BYTES = 12
private const val PBKDF2_ITERATIONS = 310_000
private const val KEY_BITS = 256

/**
 * Handles PackRat's "Encrypt uploads" feature:
 *  - A random per-drive content key, generated once.
 *  - The content key is wrapped by an Android Keystore master key so it
 *    never touches disk unwrapped.
 *  - The content key is also sealed with the user's passphrase (PBKDF2,
 *    310k iterations) and that sealed blob is uploaded to the channel as
 *    the key-backup document, so a fresh install can recover it.
 *  - File bodies are streamed through AES-256-GCM in chunks so encryption
 *    never has to hold a whole file in memory.
 */
@Singleton
class CryptoManager @Inject constructor() {

    private val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }

    private fun getOrCreateMasterKey(): SecretKey {
        (keyStore.getKey(MASTER_KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        val spec = KeyGenParameterSpec.Builder(
            MASTER_KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT,
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(KEY_BITS)
            .build()
        generator.init(spec)
        return generator.generateKey()
    }

    /** Generates a fresh random content key for a drive's "Encrypt uploads" mode. */
    fun generateContentKey(): SecretKey {
        val bytes = ByteArray(KEY_BITS / 8)
        SecureRandom().nextBytes(bytes)
        return SecretKeySpec(bytes, "AES")
    }

    /** Wraps the content key with the Keystore master key for on-device storage. */
    fun wrapContentKey(contentKey: SecretKey): WrappedKey {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateMasterKey())
        val ciphertext = cipher.doFinal(contentKey.encoded)
        return WrappedKey(iv = cipher.iv, ciphertext = ciphertext)
    }

    fun unwrapContentKey(wrapped: WrappedKey): SecretKey {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateMasterKey(), GCMParameterSpec(GCM_TAG_BITS, wrapped.iv))
        val raw = cipher.doFinal(wrapped.ciphertext)
        return SecretKeySpec(raw, "AES")
    }

    /** Seals the content key with a passphrase for the recoverable channel key-backup document. */
    fun sealContentKeyWithPassphrase(contentKey: SecretKey, passphrase: CharArray): PassphraseSealedKey {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val derived = deriveKeyFromPassphrase(passphrase, salt)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, derived)
        val ciphertext = cipher.doFinal(contentKey.encoded)
        return PassphraseSealedKey(salt = salt, iv = cipher.iv, ciphertext = ciphertext, iterations = PBKDF2_ITERATIONS)
    }

    fun unsealContentKeyWithPassphrase(sealed: PassphraseSealedKey, passphrase: CharArray): SecretKey {
        val derived = deriveKeyFromPassphrase(passphrase, sealed.salt, sealed.iterations)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, derived, GCMParameterSpec(GCM_TAG_BITS, sealed.iv))
        val raw = cipher.doFinal(sealed.ciphertext)
        return SecretKeySpec(raw, "AES")
    }

    private fun deriveKeyFromPassphrase(passphrase: CharArray, salt: ByteArray, iterations: Int = PBKDF2_ITERATIONS): SecretKey {
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val spec = PBEKeySpec(passphrase, salt, iterations, KEY_BITS)
        val raw = factory.generateSecret(spec).encoded
        return SecretKeySpec(raw, "AES")
    }

    /** Streams [input] through AES-256-GCM into [output] using [key]; returns the IV used. */
    fun encryptStream(input: InputStream, output: OutputStream, key: SecretKey): ByteArray {
        val iv = ByteArray(GCM_IV_BYTES).also { SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, iv))
        output.write(iv) // IV is prefixed so decryption is self-contained
        CipherOutputStream(output, cipher).use { cos -> input.copyTo(cos) }
        return iv
    }

    fun decryptStream(input: InputStream, output: OutputStream, key: SecretKey) {
        val iv = ByteArray(GCM_IV_BYTES)
        var read = 0
        while (read < GCM_IV_BYTES) {
            val r = input.read(iv, read, GCM_IV_BYTES - read)
            if (r == -1) error("Stream too short to contain an IV")
            read += r
        }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, iv))
        CipherInputStream(input, cipher).use { cis -> cis.copyTo(output) }
    }

    /** Obfuscated remote file name so Telegram never sees the real one. */
    fun randomRemoteFileName(): String {
        val bytes = ByteArray(16)
        SecureRandom().nextBytes(bytes)
        return bytes.joinToString("") { "%02x".format(it) } + ".bin"
    }
}

data class WrappedKey(val iv: ByteArray, val ciphertext: ByteArray)

data class PassphraseSealedKey(
    val salt: ByteArray,
    val iv: ByteArray,
    val ciphertext: ByteArray,
    val iterations: Int,
)
