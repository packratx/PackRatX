package com.packrat.app.core.transfer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.packrat.app.R

/**
 * Foreground service that keeps active transfers alive while the app is
 * backgrounded, and shows a persistent notification with aggregate
 * progress, mirroring TeleDrive's "does not have to be open or in recents"
 * backup behaviour.
 */
class TransferForegroundService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        ensureChannel()
        startForeground(NOTIFICATION_ID, buildNotification(progressText = "Syncing…"))
        return START_STICKY
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                CHANNEL_ID, "Transfers", NotificationManager.IMPORTANCE_LOW,
            )
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(progressText: String) =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("PackRat")
            .setContentText(progressText)
            .setSmallIcon(R.drawable.ic_sync)
            .setOngoing(true)
            .build()

    companion object {
        private const val CHANNEL_ID = "packrat_transfers"
        private const val NOTIFICATION_ID = 42
    }
}
