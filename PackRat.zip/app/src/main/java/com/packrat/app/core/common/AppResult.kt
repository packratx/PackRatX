package com.packrat.app.core.common

/** Typed result wrapper used across repositories and use cases instead of throwing. */
sealed class AppResult<out T> {
    data class Success<T>(val data: T) : AppResult<T>()
    data class Failure(val error: AppError) : AppResult<Nothing>()

    inline fun onSuccess(block: (T) -> Unit): AppResult<T> {
        if (this is Success) block(data)
        return this
    }

    inline fun onFailure(block: (AppError) -> Unit): AppResult<T> {
        if (this is Failure) block(error)
        return this
    }
}

sealed class AppError(val message: String, val cause: Throwable? = null) {
    data class Network(val detail: String) : AppError("Network error: $detail")
    data class TelegramApi(val code: Int, val detail: String) : AppError("Telegram error $code: $detail")
    data class NotAuthenticated(val detail: String = "Not signed in") : AppError(detail)
    data class FileTooLarge(val limitBytes: Long) : AppError("File exceeds the $limitBytes byte limit")
    data class Crypto(val detail: String) : AppError("Crypto error: $detail")
    data class Storage(val detail: String) : AppError("Storage error: $detail")
    data class Unknown(val detail: String, val err: Throwable? = null) : AppError(detail, err)
}
