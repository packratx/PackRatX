package com.packrat.app.di

import android.content.Context
import androidx.room.Room
import androidx.work.WorkManager
import com.packrat.app.core.telegram.TdLibTelegramClient
import com.packrat.app.core.telegram.TelegramClient
import com.packrat.app.data.local.PackRatDatabase
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class BindsModule {
    @Binds
    @Singleton
    abstract fun bindTelegramClient(impl: TdLibTelegramClient): TelegramClient
}

@Module
@InstallIn(SingletonComponent::class)
object ProvidesModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): PackRatDatabase =
        Room.databaseBuilder(context, PackRatDatabase::class.java, "packrat.db")
            .fallbackToDestructiveMigration()
            .build()

    @Provides
    fun provideDriveDao(db: PackRatDatabase) = db.driveDao()

    @Provides
    fun provideDriveItemDao(db: PackRatDatabase) = db.driveItemDao()

    @Provides
    fun provideTransferDao(db: PackRatDatabase) = db.transferDao()

    @Provides
    fun provideBackupRuleDao(db: PackRatDatabase) = db.backupRuleDao()

    @Provides
    @Singleton
    fun provideWorkManager(@ApplicationContext context: Context): WorkManager =
        WorkManager.getInstance(context)
}
