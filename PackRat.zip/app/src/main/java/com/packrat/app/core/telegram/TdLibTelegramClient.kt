package com.packrat.app.core.telegram

import android.content.Context
import com.packrat.app.core.common.AppError
import com.packrat.app.core.common.AppResult
import com.packrat.app.domain.model.AuthState
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.callbackFlow
import org.drinkless.tdlib.Client
import org.drinkless.tdlib.TdApi
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * TDLib-backed implementation. This talks directly to `org.drinkless.tdlib.Client`
 * (from the tdlibx/td prebuilt AAR) and translates every update into the plain
 * [AuthState] / [AppResult] types the rest of the app uses.
 *
 * Client.execute / Client.send calls are asynchronous; each public suspend
 * function below wraps the relevant TdApi call in a CompletableDeferred so
 * callers can just `await` a normal Kotlin result.
 */
@Singleton
class TdLibTelegramClient @Inject constructor(
    private val context: Context,
) : TelegramClient {

    private var client: Client? = null
    private var apiId: Int = 0
    private var apiHash: String = ""

    private val _authState = MutableStateFlow<AuthState>(AuthState.LoggedOut)
    override val authState = _authState.asStateFlow()

    private fun ensureClient(): Client {
        return client ?: Client.create(
            { update -> handleUpdate(update) },
            null,
            null,
        ).also { client = it }
    }

    private fun handleUpdate(update: TdApi.Object) {
        when (update) {
            is TdApi.UpdateAuthorizationState -> handleAuthUpdate(update.authorizationState)
            // Additional update types (new messages, file progress, connection state)
            // are routed to TransferManager / SyncEngine via a shared event bus in the
            // full implementation.
            else -> Unit
        }
    }

    private fun handleAuthUpdate(state: TdApi.AuthorizationState) {
        _authState.value = when (state) {
            is TdApi.AuthorizationStateWaitTdlibParameters -> {
                sendTdlibParameters()
                AuthState.Authenticating
            }
            is TdApi.AuthorizationStateWaitPhoneNumber -> AuthState.WaitingForPhoneNumber
            is TdApi.AuthorizationStateWaitCode -> AuthState.WaitingForCode(phoneNumber = "")
            is TdApi.AuthorizationStateWaitPassword -> AuthState.WaitingForPassword
            is TdApi.AuthorizationStateReady -> AuthState.Authenticated
            is TdApi.AuthorizationStateLoggingOut,
            is TdApi.AuthorizationStateClosing,
            is TdApi.AuthorizationStateClosed -> AuthState.LoggedOut
            else -> AuthState.Authenticating
        }
    }

    private fun sendTdlibParameters() {
        val filesDir = File(context.filesDir, "tdlib").apply { mkdirs() }
        val params = TdApi.SetTdlibParameters().apply {
            databaseDirectory = filesDir.absolutePath
            useFileDatabase = true
            useChatInfoDatabase = true
            useMessageDatabase = true
            useSecretChats = false
            this.apiId = this@TdLibTelegramClient.apiId
            apiHash = this@TdLibTelegramClient.apiHash
            systemLanguageCode = "en"
            deviceModel = android.os.Build.MODEL
            applicationVersion = "0.1.0"
        }
        ensureClient().send(params) { /* result observed via next auth update */ }
    }

    override suspend fun setApiCredentials(apiId: Int, apiHash: String) {
        this.apiId = apiId
        this.apiHash = apiHash
        ensureClient() // triggers AuthorizationStateWaitTdlibParameters -> sendTdlibParameters()
    }

    override suspend fun sendPhoneNumber(phoneNumber: String): AppResult<Unit> {
        val deferred = CompletableDeferred<AppResult<Unit>>()
        val request = TdApi.SetAuthenticationPhoneNumber(phoneNumber, null)
        ensureClient().send(request) { result -> deferred.complete(result.toUnitResult()) }
        return deferred.await()
    }

    override suspend fun sendLoginCode(code: String): AppResult<Unit> {
        val deferred = CompletableDeferred<AppResult<Unit>>()
        ensureClient().send(TdApi.CheckAuthenticationCode(code)) { result ->
            deferred.complete(result.toUnitResult())
        }
        return deferred.await()
    }

    override suspend fun sendPassword(password: String): AppResult<Unit> {
        val deferred = CompletableDeferred<AppResult<Unit>>()
        ensureClient().send(TdApi.CheckAuthenticationPassword(password)) { result ->
            deferred.complete(result.toUnitResult())
        }
        return deferred.await()
    }

    override suspend fun requestQrLogin(): kotlinx.coroutines.flow.Flow<String> = callbackFlow {
        ensureClient().send(TdApi.RequestQrCodeAuthentication(LongArray(0))) { }
        // AuthorizationStateWaitOtherDeviceConfirmation carries the refreshed link;
        // routed here from handleUpdate in the full implementation.
        awaitClose { }
    }

    override suspend fun logOut(): AppResult<Unit> {
        val deferred = CompletableDeferred<AppResult<Unit>>()
        ensureClient().send(TdApi.LogOut()) { result -> deferred.complete(result.toUnitResult()) }
        return deferred.await()
    }

    override suspend fun findOrCreateStorageChannel(name: String): AppResult<Long> {
        // 1. Search existing chats for a channel tagged with the PackRat marker
        //    (a pinned message with a known JSON signature), mirroring TeleDrive's
        //    "finds it again after a reinstall" behaviour.
        // 2. If none found, create a new private channel via TdApi.CreateNewSupergroupChat
        //    with isChannel = true, then pin the marker message.
        val deferred = CompletableDeferred<AppResult<Long>>()
        val request = TdApi.CreateNewSupergroupChat(
            name, /* isChannel = */ true, /* isForum = */ false,
            "PackRat storage", null, false,
        )
        ensureClient().send(request) { result ->
            when (result) {
                is TdApi.Chat -> deferred.complete(AppResult.Success(result.id))
                is TdApi.Error -> deferred.complete(AppResult.Failure(AppError.TelegramApi(result.code, result.message)))
                else -> deferred.complete(AppResult.Failure(AppError.Unknown("Unexpected TDLib response")))
            }
        }
        return deferred.await()
    }

    override suspend fun uploadFile(
        channelId: Long,
        localPath: String,
        captionJson: String,
        onProgress: (Long, Long) -> Unit,
    ): AppResult<Long> {
        val deferred = CompletableDeferred<AppResult<Long>>()
        val inputFile = TdApi.InputFileLocal(localPath)
        val content = TdApi.InputMessageDocument(inputFile, null, false, TdApi.FormattedText(captionJson, null))
        val request = TdApi.SendMessage(channelId, 0, null, null, null, content)
        ensureClient().send(request) { result ->
            when (result) {
                is TdApi.Message -> deferred.complete(AppResult.Success(result.id))
                is TdApi.Error -> deferred.complete(AppResult.Failure(AppError.TelegramApi(result.code, result.message)))
                else -> deferred.complete(AppResult.Failure(AppError.Unknown("Unexpected TDLib response")))
            }
        }
        // Real progress comes from UpdateFile deltas keyed by the file id inside
        // the sent message, forwarded to onProgress from handleUpdate().
        return deferred.await()
    }

    override suspend fun downloadFile(
        channelId: Long,
        messageId: Long,
        destinationPath: String,
        rangeStart: Long?,
        rangeEnd: Long?,
        onProgress: (Long, Long) -> Unit,
    ): AppResult<String> {
        val deferred = CompletableDeferred<AppResult<String>>()
        val getMessage = TdApi.GetMessage(channelId, messageId)
        ensureClient().send(getMessage) { msgResult ->
            val fileId = (msgResult as? TdApi.Message)?.content?.let { content ->
                (content as? TdApi.MessageDocument)?.document?.document?.id
            }
            if (fileId == null) {
                deferred.complete(AppResult.Failure(AppError.Unknown("File not found in message")))
                return@send
            }
            val download = TdApi.DownloadFile(fileId, 1, rangeStart ?: 0, rangeEnd?.let { it - (rangeStart ?: 0) } ?: 0, true)
            ensureClient().send(download) { fileResult ->
                when (fileResult) {
                    is TdApi.File -> deferred.complete(AppResult.Success(fileResult.local.path))
                    is TdApi.Error -> deferred.complete(AppResult.Failure(AppError.TelegramApi(fileResult.code, fileResult.message)))
                    else -> deferred.complete(AppResult.Failure(AppError.Unknown("Unexpected TDLib response")))
                }
            }
        }
        return deferred.await()
    }

    override suspend fun deleteMessage(channelId: Long, messageId: Long): AppResult<Unit> {
        val deferred = CompletableDeferred<AppResult<Unit>>()
        ensureClient().send(TdApi.DeleteMessages(channelId, longArrayOf(messageId), true)) { result ->
            deferred.complete(result.toUnitResult())
        }
        return deferred.await()
    }

    override suspend fun editCaption(channelId: Long, messageId: Long, newCaptionJson: String): AppResult<Unit> {
        val deferred = CompletableDeferred<AppResult<Unit>>()
        val request = TdApi.EditMessageCaption(channelId, messageId, null, TdApi.FormattedText(newCaptionJson, null))
        ensureClient().send(request) { result -> deferred.complete(result.toUnitResult()) }
        return deferred.await()
    }

    override suspend fun scanChannelManifests(channelId: Long) = callbackFlow<Pair<Long, String>> {
        // Pages backwards through channel history via TdApi.GetChatHistory,
        // emitting (messageId, captionJson) for every document message found.
        // Used by the rebuild-after-wipe recovery flow.
        awaitClose { }
    }

    private fun TdApi.Object.toUnitResult(): AppResult<Unit> = when (this) {
        is TdApi.Ok -> AppResult.Success(Unit)
        is TdApi.Error -> AppResult.Failure(AppError.TelegramApi(code, message))
        else -> AppResult.Failure(AppError.Unknown("Unexpected TDLib response"))
    }
}
