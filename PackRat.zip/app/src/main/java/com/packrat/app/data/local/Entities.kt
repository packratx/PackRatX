package com.packrat.app.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "drives")
data class DriveEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val telegramChannelId: Long,
    val isActive: Boolean,
    val encryptionEnabled: Boolean,
    val wrappedKeyIv: ByteArray? = null,
    val wrappedKeyCiphertext: ByteArray? = null,
)

@Entity(tableName = "drive_items")
data class DriveItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val driveId: Long,
    val remoteMessageId: Long?,
    val parentFolderId: Long?,
    val name: String,
    val isFolder: Boolean,
    val mimeType: String?,
    val sizeBytes: Long,
    val sha256: String?,
    val isEncrypted: Boolean,
    val remoteFileName: String?, // obfuscated name when encrypted
    val isFavorite: Boolean = false,
    val isHidden: Boolean = false,
    val isArchived: Boolean = false,
    val isTrashed: Boolean = false,
    val createdAt: Long,
    val modifiedAt: Long,
)

@Entity(tableName = "transfers")
data class TransferEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val driveItemId: Long?,
    val driveId: Long,
    val localPath: String,
    val fileName: String,
    val direction: String, // "UPLOAD" | "DOWNLOAD"
    val status: String,
    val progressBytes: Long = 0,
    val totalBytes: Long,
    val priority: Int = 0,
    val errorMessage: String? = null,
    val createdAt: Long,
)

@Entity(tableName = "backup_rules")
data class BackupRuleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val driveId: Long,
    val watchedFolderPath: String,
    val destinationFolderId: Long,
    val wifiOnly: Boolean = true,
    val chargingOnly: Boolean = false,
    val excludePatternsCsv: String = "",
    val runOnAppear: Boolean = true,
)
