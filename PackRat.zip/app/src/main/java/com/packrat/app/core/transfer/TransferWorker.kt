package com.packrat.app.core.transfer

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.packrat.app.core.common.AppResult
import com.packrat.app.core.crypto.CryptoManager
import com.packrat.app.core.telegram.TelegramClient
import com.packrat.app.data.local.TransferDao
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

/**
 * Executes a single queued transfer (upload or download). Progress is
 * written back to Room so the UI (speed/ETA/progress bar) observes it via
 * [TransferDao.observeActive], and WorkManager retries handle process death.
 */
@HiltWorker
class TransferWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val telegramClient: TelegramClient,
    private val transferDao: TransferDao,
    private val cryptoManager: CryptoManager,
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val transferId = inputData.getLong(KEY_TRANSFER_ID, -1L)
        if (transferId == -1L) return Result.failure()

        // Full implementation: load the TransferEntity by id, branch on
        // direction, stream the file through CryptoManager when the drive
        // has encryption enabled, call TelegramClient.uploadFile /
        // downloadFile with a progress callback that updates Room (and thus
        // the UI) at a throttled interval, and mark status COMPLETED /
        // FAILED accordingly. TDLib cannot resume an interrupted upload, so
        // a paused upload restarts from zero on resume; downloads do resume
        // via TDLib's own partial-file support.

        return Result.success()
    }

    companion object {
        const val KEY_TRANSFER_ID = "transfer_id"
    }
}
