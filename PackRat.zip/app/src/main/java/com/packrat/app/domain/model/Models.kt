package com.packrat.app.domain.model

/** A file or folder in the user's PackRat drive, mirrored from the Telegram channel. */
data class DriveItem(
    val id: Long,
    val remoteMessageId: Long?,
    val parentFolderId: Long?,
    val name: String,
    val isFolder: Boolean,
    val mimeType: String?,
    val sizeBytes: Long,
    val sha256: String?,
    val isEncrypted: Boolean,
    val isFavorite: Boolean = false,
    val isHidden: Boolean = false,
    val isArchived: Boolean = false,
    val isTrashed: Boolean = false,
    val createdAt: Long,
    val modifiedAt: Long,
)

data class Drive(
    val id: Long,
    val name: String,
    val telegramChannelId: Long,
    val isActive: Boolean,
    val encryptionEnabled: Boolean,
)

enum class TransferDirection { UPLOAD, DOWNLOAD }

enum class TransferStatus { QUEUED, RUNNING, PAUSED, COMPLETED, FAILED, CANCELLED }

data class TransferItem(
    val id: Long,
    val driveItemId: Long?,
    val localPath: String,
    val fileName: String,
    val direction: TransferDirection,
    val status: TransferStatus,
    val progressBytes: Long,
    val totalBytes: Long,
    val priority: Int = 0,
    val speedBytesPerSec: Long = 0,
    val etaSeconds: Long? = null,
    val errorMessage: String? = null,
)

sealed class AuthState {
    data object LoggedOut : AuthState()
    data object WaitingForApiCredentials : AuthState()
    data object WaitingForPhoneNumber : AuthState()
    data class WaitingForCode(val phoneNumber: String) : AuthState()
    data object WaitingForQrConfirmation : AuthState()
    data object WaitingForPassword : AuthState()
    data object Authenticating : AuthState()
    data object Authenticated : AuthState()
}

data class BackupRule(
    val id: Long,
    val watchedFolderPath: String,
    val destinationFolderId: Long,
    val wifiOnly: Boolean = true,
    val chargingOnly: Boolean = false,
    val excludePatterns: List<String> = emptyList(),
    val runOnAppear: Boolean = true,
)
