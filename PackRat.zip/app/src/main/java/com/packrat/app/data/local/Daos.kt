package com.packrat.app.data.local

import androidx.paging.PagingSource
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface DriveDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(drive: DriveEntity): Long

    @Query("SELECT * FROM drives")
    fun observeAll(): Flow<List<DriveEntity>>

    @Query("SELECT * FROM drives WHERE isActive = 1 LIMIT 1")
    suspend fun getActive(): DriveEntity?
}

@Dao
interface DriveItemDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: DriveItemEntity): Long

    @Update
    suspend fun update(item: DriveItemEntity)

    @Query(
        "SELECT * FROM drive_items WHERE driveId = :driveId AND parentFolderId IS :parentFolderId " +
            "AND isTrashed = 0 AND isHidden = 0 ORDER BY isFolder DESC, name COLLATE NOCASE ASC",
    )
    fun pagingByFolder(driveId: Long, parentFolderId: Long?): PagingSource<Int, DriveItemEntity>

    @Query("SELECT * FROM drive_items WHERE driveId = :driveId AND sha256 = :sha256 AND isTrashed = 0 LIMIT 1")
    suspend fun findByHash(driveId: Long, sha256: String): DriveItemEntity?

    @Query("SELECT * FROM drive_items WHERE driveId = :driveId AND isFavorite = 1 AND isTrashed = 0")
    fun observeFavorites(driveId: Long): Flow<List<DriveItemEntity>>

    @Query("SELECT * FROM drive_items WHERE driveId = :driveId AND isTrashed = 1")
    fun observeTrash(driveId: Long): Flow<List<DriveItemEntity>>

    @Query(
        "SELECT mimeType, SUM(sizeBytes) as total FROM drive_items " +
            "WHERE driveId = :driveId AND isFolder = 0 AND isTrashed = 0 GROUP BY mimeType",
    )
    suspend fun storageBreakdown(driveId: Long): List<MimeTotal>

    @Query("UPDATE drive_items SET isTrashed = 1 WHERE id = :id")
    suspend fun moveToTrash(id: Long)

    @Query("UPDATE drive_items SET isTrashed = 0 WHERE id = :id")
    suspend fun restoreFromTrash(id: Long)
}

data class MimeTotal(val mimeType: String?, val total: Long)

@Dao
interface TransferDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(transfer: TransferEntity): Long

    @Update
    suspend fun update(transfer: TransferEntity)

    @Query("SELECT * FROM transfers WHERE status IN ('QUEUED', 'RUNNING', 'PAUSED') ORDER BY priority DESC, createdAt ASC")
    fun observeActive(): Flow<List<TransferEntity>>

    @Query("DELETE FROM transfers WHERE status = 'COMPLETED' AND createdAt < :beforeTimestamp")
    suspend fun pruneCompleted(beforeTimestamp: Long)
}

@Dao
interface BackupRuleDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(rule: BackupRuleEntity): Long

    @Query("SELECT * FROM backup_rules WHERE driveId = :driveId")
    fun observeForDrive(driveId: Long): Flow<List<BackupRuleEntity>>
}
