package com.packrat.app.core.transfer

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager

/** Re-arms the hourly backup sweep and resumes any queued transfers after a reboot. */
class BootCompletedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val request = OneTimeWorkRequestBuilder<BackupSweepWorker>().build()
        WorkManager.getInstance(context).enqueue(request)
    }
}
