pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // TDLib prebuilt Android AAR (mirrors TeleDrive's approach: tdlibx/td via JitPack)
        maven(url = "https://jitpack.io")
    }
}

rootProject.name = "PackRat"
include(":app")
